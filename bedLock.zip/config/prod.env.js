'use strict'
module.exports = {
  NODE_ENV: '"production"',
  API_ROOT:'"http://39.104.99.181:12000"'//家庭
  // API_ROOT:'"http://39.104.99.181:12010"'//客户
  // API_ROOT:'"http://39.104.113.112:20189"'//客服
}

